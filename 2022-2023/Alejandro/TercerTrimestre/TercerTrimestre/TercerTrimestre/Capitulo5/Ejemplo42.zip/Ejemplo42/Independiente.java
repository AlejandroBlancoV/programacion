package Capitulo5.Ejemplo42;

public class Independiente extends Urbana{
    
}
