package Capitulo5.Ejemplo42;

public class Estudio extends Apartamento{
    
}
