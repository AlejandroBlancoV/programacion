package Capitulo5.Ejemplo42;

public class Urbana extends Casa{
    
}
