package Capitulo5.Ejemplo42;

public class Inmueble {
    protected int idTipo;
    protected int area;
    protected String direccion;
    protected double precio;

}
