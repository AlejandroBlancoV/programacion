package Capitulo5.Ejemplo42;

public class Vivienda extends Inmueble{
    
}
