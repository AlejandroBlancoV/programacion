package Capitulo5.Ejemplo42;

public class Local extends Inmueble{
    
}
