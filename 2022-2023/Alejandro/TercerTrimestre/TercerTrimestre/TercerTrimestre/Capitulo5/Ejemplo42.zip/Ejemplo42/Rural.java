package Capitulo5.Ejemplo42;

public class Rural extends Casa{
    
}
