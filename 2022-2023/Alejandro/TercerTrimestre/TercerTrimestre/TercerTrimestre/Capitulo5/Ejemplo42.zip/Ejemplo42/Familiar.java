package Capitulo5.Ejemplo42;

public class Familiar extends Apartamento{
    
}
